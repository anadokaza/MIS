import 'package:flutter/material.dart';
import '../models/joke_model.dart';
import '../services/api_service.dart';
import '../services/favorite_service.dart';
import '../widgets/joke_card.dart';
import '../widgets/auth_guard.dart';

class JokesList extends StatefulWidget {
  const JokesList({super.key});

  @override
  State<JokesList> createState() => _JokesListState();
}

class _JokesListState extends State<JokesList> {
  List<Joke> jokes = [];
  String type = '';
  final FavoriteService _favoriteService = FavoriteService();
  Map<int, bool> favoriteStatus = {};
  bool isLoading = true;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    type = ModalRoute.of(context)?.settings.arguments as String;
    getJokes();
  }

  void getJokes() async {
    setState(() {
      isLoading = true;
    });

    ApiService.getJokesByType(type).then((response) async {
      for (var joke in response) {
        favoriteStatus[joke.id] = await _favoriteService.isFavorite(joke.id);
      }
      setState(() {
        jokes = response;
        isLoading = false;
      });
    });
  }

  void toggleFavorite(Joke joke) async {
    final currentStatus = favoriteStatus[joke.id] ?? false;

    setState(() {
      favoriteStatus[joke.id] = !currentStatus;
    });

    try {
      if (currentStatus) {
        await _favoriteService.removeFavorite(joke.id);
      } else {
        await _favoriteService.addFavorite(joke);
      }
    } catch (e) {
      setState(() {
        favoriteStatus[joke.id] = currentStatus;
      });

      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to update favorite status'))
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return AuthGuard(
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            "${type.toUpperCase()} Jokes",
            style: const TextStyle(color: Colors.white),
          ),
          backgroundColor: Colors.pinkAccent,
        ),
        body: isLoading
            ? const Center(
          child: CircularProgressIndicator(color: Colors.pinkAccent),
        )
            : Container(
          color: Colors.white,
          child: ListView.builder(
            itemCount: jokes.length,
            itemBuilder: (context, index) => JokeCard(
              joke: jokes[index],
              isFavorite: favoriteStatus[jokes[index].id] ?? false,
              onFavoritePressed: () => toggleFavorite(jokes[index]),
            ),
          ),
        ),
      ),
    );
  }
}