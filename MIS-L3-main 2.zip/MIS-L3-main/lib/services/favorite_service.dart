import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../models/joke_model.dart';

class FavoriteService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<void> addFavorite(Joke joke) async {
    final user = _auth.currentUser;
    if (user != null) {
      await _firestore
          .collection('users')
          .doc(user.uid)
          .collection('favorites')
          .doc(joke.id.toString())
          .set({
        'id': joke.id,
        'type': joke.type,
        'setup': joke.setup,
        'punchline': joke.punchline,
      });
    }
  }

  Future<void> removeFavorite(int jokeId) async {
    final user = _auth.currentUser;
    if (user != null) {
      await _firestore
          .collection('users')
          .doc(user.uid)
          .collection('favorites')
          .doc(jokeId.toString())
          .delete();
    }
  }

  Stream<List<Joke>> getFavorites() {
    final user = _auth.currentUser;
    if (user != null) {
      return _firestore
          .collection('users')
          .doc(user.uid)
          .collection('favorites')
          .snapshots()
          .map((snapshot) => snapshot.docs
          .map((doc) => Joke(
        id: doc.data()['id'],
        type: doc.data()['type'],
        setup: doc.data()['setup'],
        punchline: doc.data()['punchline'],
      ))
          .toList());
    }
    return Stream.value([]);
  }

  Future<bool> isFavorite(int jokeId) async {
    final user = _auth.currentUser;
    if (user != null) {
      final doc = await _firestore
          .collection('users')
          .doc(user.uid)
          .collection('favorites')
          .doc(jokeId.toString())
          .get();
      return doc.exists;
    }
    return false;
  }
}