import 'package:flutter/material.dart';
import '../models/joke_model.dart';
import '../services/favorite_service.dart';

class JokeCard extends StatelessWidget {
  final Joke joke;
  final bool isFavorite;
  final VoidCallback? onFavoritePressed;

  const JokeCard({
    super.key,
    required this.joke,
    this.isFavorite = false,
    this.onFavoritePressed,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.all(8),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    joke.setup,
                    style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold
                    ),
                  ),
                ),
                IconButton(
                  icon: Icon(
                    isFavorite ? Icons.favorite : Icons.favorite_border,
                    color: isFavorite ? Colors.red : null,
                  ),
                  onPressed: onFavoritePressed ?? () {
                    FavoriteService().addFavorite(joke);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Added to favorites')),
                    );
                  },
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              joke.punchline,
              style: const TextStyle(fontSize: 16),
            ),
          ],
        ),
      ),
    );
  }
}